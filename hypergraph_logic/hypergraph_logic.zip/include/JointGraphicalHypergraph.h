#pragma once
#include "GraphicalHypergraph.h"

#include <stdexcept>
#include <string>
#include <unordered_set>
#include <memory>

using json = nlohmann::json;

namespace hypergraph_logic {

	// ============================================================================
	// JointGraphicalHypergraph
	//
	// A per-project singleton that aggregates several GraphicalHypergraph
	// instances into a single joint view, side-by-side within shared layers.
	//
	// Ownership: JointGraphicalHypergraph is owned exclusively by the Project
	// object.  The Project constructs it via JointGraphicalHypergraph::create()
	// and holds the unique_ptr.  No second instance can be created while one is
	// alive; attempting to do so throws std::logic_error.
	//
	// Snapshots: addHypergraph() deep-copies the supplied graph before merging
	// it.  Subsequent mutations on the original graph are never reflected here,
	// and mutations performed on the joint graph are never reflected back.
	//
	// Node-creation API: createNode, createSource and createTarget are disabled.
	// All other public Hypergraph / GraphicalHypergraph methods (addConnection,
	// removeNode, removeConnection, removeSourcesFromHyperedge,
	// removeTargetsFromHyperedge, fuseNodes, computeLayout, ...) remain active.
	//
	// Layer merging: when a graph is incorporated its nodes and edges are placed
	// into the joint's layers by the same index (layer 0 of the incoming graph
	// goes into layer 0 of the joint, etc.).  Layers that do not yet exist in
	// the joint are created on demand.  Depending on the 'left' argument the
	// incoming nodes and edges are prepended (left=true) or appended (left=false)
	// to the existing LayerData vectors, reflecting whether the user dropped the
	// graph to the left or right of all currently present content.
	//
	// Singleton guard:
	// instance_exists_ tracks whether the live (non-snapshot) instance exists.
	// Snapshot instances created by cloneJoint() carry is_snapshot_ = true and
	// do not affect the guard: they are internal undo/redo bookkeeping objects,
	// not user-facing singletons.  Only the instance returned by create() has
	// is_snapshot_ = false and its destructor resets the guard.
	// ============================================================================
#ifdef JGH_TEST
	namespace jointgraphicalhypergraph_tests { class TestableJoint; }
#endif
	class JointGraphicalHypergraph : public GraphicalHypergraph {
#ifdef JGH_TEST
		friend class jointgraphicalhypergraph_tests::TestableJoint;
#endif
	public:
		// ── Singleton management ─────────────────────────────────────────────────

		// ── create ───────────────────────────────────────────────────────────────
		//
		// Factory method — the only way to obtain a live JointGraphicalHypergraph.
		// At most one live instance may exist at any time within a single project
		// scope.  The caller (Project) is responsible for destroying the returned
		// object before creating a new one for a different project.
		//
		// Throws std::logic_error if a live instance already exists.
		static std::unique_ptr<JointGraphicalHypergraph> create(const std::string& name);

		// ── cloneJoint ───────────────────────────────────────────────────────────
		//
		// Produces a fully independent deep copy of this joint graph, including all
		// layout data and the incorporated_ids_ set. The clone is flagged as a
		// snapshot (is_snapshot_ = true) so its destructor does not release the
		// singleton slot — snapshot instances are internal undo/redo bookkeeping
		// objects and must not interfere with the live singleton guard.
		//
		// Called exclusively by JointHypergraphEditor::snapshot().
		std::unique_ptr<JointGraphicalHypergraph> cloneJoint() const;

		// Destructor: releases the singleton slot only if this is the live instance.
		~JointGraphicalHypergraph();

		// Non-copyable, non-movable — the singleton guarantee would be violated.
		JointGraphicalHypergraph(const JointGraphicalHypergraph&) = delete;
		JointGraphicalHypergraph& operator=(const JointGraphicalHypergraph&) = delete;
		JointGraphicalHypergraph(JointGraphicalHypergraph&&) = delete;
		JointGraphicalHypergraph& operator=(JointGraphicalHypergraph&&) = delete;

		// ── Disabled node-creation API ────────────────────────────────────────────
		//
		// Nodes may only enter the joint graph through addHypergraph().
		// Calling any of these methods throws std::logic_error.
		NodePtr createNode(const std::string&, int, const NodePtr&) {
			throw std::logic_error(
				"JointGraphicalHypergraph: createNode is disabled. "
				"Add nodes via addHypergraph().");
		}
		NodePtr createNode(const std::string&, const HyperedgePtr&) {
			throw std::logic_error(
				"JointGraphicalHypergraph: createNode is disabled. "
				"Add nodes via addHypergraph().");
		}
		NodePtr createSource(const std::string&, int, const HyperedgePtr&) {
			throw std::logic_error(
				"JointGraphicalHypergraph: createSource is disabled. "
				"Add nodes via addHypergraph().");
		}
		NodePtr createTarget(const std::string&, int, const HyperedgePtr&) {
			throw std::logic_error(
				"JointGraphicalHypergraph: createTarget is disabled. "
				"Add nodes via addHypergraph().");
		}

		// ── addHypergraph ─────────────────────────────────────────────────────────
		//
		// Incorporates a deep copy of the given GraphicalHypergraph into the joint.
		//
		// The supplied graph is identified by its unique ID. Attempting to add a
		// graph whose ID has already been incorporated throws std::invalid_argument.
		// Because clone() preserves the ID, passing a clone of a previously added
		// graph is also rejected — the check is on logical identity, not pointer
		// equality.
		//
		// Internally, addHypergraph clones the source graph and delegates the actual
		// structural merge to GraphicalHypergraph::mergeFrom(), which splices all
		// nodes, edges, segments, layer memberships, and layout data into the joint.
		// The original graph is never modified.
		//
		// The left flag controls the horizontal placement of the incoming graph
		// relative to the content already present in the joint:
		//   left = true  — the incoming graph is placed to the left of all existing
		//                  content (nodes and edges are prepended in each layer).
		//   left = false — the incoming graph is placed to the right of all existing
		//                  content (nodes and edges are appended in each layer).
		//
		void addHypergraph(GraphicalHypergraph& g, bool left);

		// ── getIncorporatedIds ────────────────────────────────────────────────────
		//
		// Returns the set of IDs of every GraphicalHypergraph that has been
		// incorporated into this joint so far.
		//
		const std::unordered_set<std::string>& getIncorporatedIds() const;

		// ── Persistence ───────────────────────────────────────────────────────────

		// ── toJSON ────────────────────────────────────────────────────────────────
		//
		// Extends GraphicalHypergraph::toJSON(json&) by also writing the
		// incorporated_ids_ set under the key "incorporated_ids". This allows the
		// joint to be fully round-tripped without re-adding each diagram manually.
		//
		void toJSON(nlohmann::json& j) const;

		// Convenience overload: serializes to a JSON file at the given path.
		void toJSON(const std::string& path) const;

		// ── fromJSON ──────────────────────────────────────────────────────────────
		//
		// Static factory that reconstructs a live JointGraphicalHypergraph from a
		// json object previously produced by toJSON(json&), restoring both the
		// graph topology/layout and the incorporated_ids_ set.
		// Throws std::logic_error if a live instance already exists.
		//
		static std::unique_ptr<JointGraphicalHypergraph> fromJSON(const nlohmann::json& j);

		// Convenience overload: deserializes from a JSON file at the given path.
		// Throws std::runtime_error if the file cannot be opened or is malformed.
		static std::unique_ptr<JointGraphicalHypergraph> fromJSON(const std::string& path);

	private:
		// ── Private constructors ──────────────────────────────────────────────────

		// Constructor for live instances (called by create()).
		explicit JointGraphicalHypergraph(const std::string& name);

		// Constructor for snapshot instances (called by cloneJoint()).
		// Bypasses the singleton guard entirely; is_snapshot_ is set to true.
		explicit JointGraphicalHypergraph(
			const std::string& name,
			const std::unordered_set<std::string>& ids);

		// ── Singleton guard ───────────────────────────────────────────────────────
		//
		// true while the live (non-snapshot) instance exists.
		// Snapshot instances do not set or clear this flag.
		//
		static bool instance_exists_;

		// true for snapshot instances created by cloneJoint().
		// This allows multiple copies without really violating the singleton guarantee,
		// since logically there is only one joint graph in the current project state.
		bool is_snapshot_ = false;

		// IDs of graphs that have already been incorporated, used to enforce
		// the "no duplicate" rule in addHypergraph().
		std::unordered_set<std::string> incorporated_ids_;
	};

} // namespace hypergraph_logic